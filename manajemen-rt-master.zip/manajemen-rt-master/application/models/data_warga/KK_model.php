<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class KK_model extends CI_Model {
     
  public function __construct()
  {
      parent::__construct();		
  }

  public function getKKHeader($id = null){
    if(is_null($id)){
      $query = $this->db->query("SELECT * FROM m_kk_header a");
      return $query->result();
    }else{
      $query = $this->db->query("SELECT * FROM m_kk_header WHERE mhkk_id = '" . $id . "'");
      return $query->result();
    }
  }

  public function chekKK($noKK = null){
    $query = $this->db->query("SELECT * FROM m_kk_header WHERE mhkk_nokk = '" . $noKK . "'");
    return $query->num_rows();
  }

  public function addKKHeader($noKK,$nmKepalaKK,$alamatKK){    
    $this->db->query(
      "INSERT INTO m_kk_header (mhkk_NoKK,mhkk_Nama,mhkk_Alamat)
        VALUES ('{$noKK}','{$nmKepalaKK}','{$alamatKK}')"
    );
    $afftectedRows = $this->db->affected_rows();
    if($afftectedRows > 0){
      return "OK";
    }else{
      return "ERROR";
    }
  }

  public function getKKDetail($id = null){
    $query = $this->db->query("SELECT * FROM m_kk_detail WHERE mdkk_hid = '" . $id . "'");
    return $query->result();
  }

  public function getEditDetail($id = null){
    $query = $this->db->query("SELECT * FROM m_kk_detail WHERE mdkk_id = '" . $id . "'");
    return $query->row();
  }

  public function chekNIK($nik = null){
    $query = $this->db->query("SELECT * FROM m_kk_detail WHERE mdkk_nik = '" . $nik . "'");
    return $query->num_rows();
  }

  public function addKKDetail($idKK){    
    $nik = $this->input->post('nik');
    $nama = $this->input->post('nama');
    $jk = $this->input->post('jk');
    $tmpLahir = $this->input->post('tmp-lahir');
    $tglLahir = $this->input->post('tgl-lahir');
    $agama = $this->input->post('agama');
    $pendidikan = $this->input->post('pendidikan');
    $pekerjaan = $this->input->post('pekerjaan');

    $this->db->query(
      "INSERT INTO m_kk_detail (mdkk_hid,mdkk_nik,mdkk_nama,mdkk_jk,mdkk_tmpLahir,mdkk_tglLahir,mdkk_agama,mdkk_pendidikan,mdkk_pekerjaan)
        VALUES ('{$idKK}','{$nik}','{$nama}','{$jk}','{$tmpLahir}','{$tglLahir}','{$agama}','{$pendidikan}','{$pekerjaan}')"
    );

    $afftectedRows = $this->db->affected_rows();
    if($afftectedRows > 0){
      return "OK";
    }else{
      return "ERROR";
    }
  }

  public function editKKDetail(){    
    $id = $this->input->post('id');
    $nik = $this->input->post('nik');
    $nama = $this->input->post('nama');
    $jk = $this->input->post('jk');
    $tmpLahir = $this->input->post('tmp-lahir');
    $tglLahir = $this->input->post('tgl-lahir');
    $agama = $this->input->post('agama');
    $pendidikan = $this->input->post('pendidikan');
    $pekerjaan = $this->input->post('pekerjaan');

    $this->db->query(
      "UPDATE m_kk_detail 
        SET mdkk_nik = '" . $nik . "',
            mdkk_nama = '" . $nama . "',
            mdkk_jk = '" . $jk . "',
            mdkk_tmpLahir = '" . $tmpLahir . "',
            mdkk_tglLahir = '" . $tglLahir . "',
            mdkk_agama = '" . $agama . "',
            mdkk_pendidikan = '" . $pendidikan . "',
            mdkk_pekerjaan = '" . $pekerjaan . "'
        WHERE mdkk_id = '" . $id . "'"
    );

    $afftectedRows = $this->db->affected_rows();
    if($afftectedRows > 0){
      return "OK";
    }else{
      return "ERROR";
    }
  }

  public function deleteKKDetail($idH,$idD){        
    $this->db->query(
      "DELETE FROM m_kk_detail WHERE mdkk_id = '" . $idH . "' AND mdkk_hid = '" . $idH . "'"
    );

    $afftectedRows = $this->db->affected_rows();
    if($afftectedRows > 0){
      return "OK";
    }else{
      return "ERROR";
    }
  }
}
