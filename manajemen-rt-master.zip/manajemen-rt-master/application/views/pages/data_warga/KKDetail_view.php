<main>
  <div class="container-fluid">
    <h1 class="mt-4">Data Warga</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">Master</li>
        <li class="breadcrumb-item">Data Warga</li>
        <li class="breadcrumb-item active">Add Anggota Keluarga</li>
    </ol>

    <!-- Alert Message -->
    <?= $this->session->flashdata('message'); ?>
    
    <a class="btn btn-primary mb-4 btn-sm" href="<?= base_url("DataKK") ?>">
      <i class="fa fa-arrow-left" aria-hidden="true"></i>
      Back
    </a>

    <div class="card mb-4">
      <div class="card-body">
        <?php 
          $idKK = "";
          foreach ($header as $r) { ?>
          <input class="form-control mb-3" type="text" value="<?= $r->mhkk_NoKK; ?>" disabled>
          <input class="form-control mb-3" type="text" value="<?= $r->mhkk_Nama; ?>" disabled>
          <textarea class="form-control mb-3" disabled><?= $r->mhkk_Alamat; ?></textarea>
        <?php $idKK = $r->mhkk_id; } ?>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header">
          <i class="fa fa-plus mr-1"></i>
          Data Anggota Keluarga
      </div>
      <div class="card-body">
        <form action="<?= base_url('DataKK/addKKDetail/' . $idKK ) ?>" method="post">
          <?php if(is_null($edit)){ ?>
            <!-- Add Data -->
            <input class="form-control mb-3" type="hidden" name="id" value="">
            <input class="form-control mb-3" type="text" name="nik" placeholder="NIK" required>
            <input class="form-control mb-3" type="text" name="nama" placeholder="Nama" required>
            
            <div class="form-check form-check-inline mb-3">
              <input class="form-check-input" type="radio" name="jk" id="radio1" value="L" required>
              <label class="form-check-label mr-3" for="radio1">Laki-Laki</label>
              <input class="form-check-input" type="radio" name="jk" id="radio2" value="P" required>
              <label class="form-check-label mr-3" for="radio2">Perempuan</label>
            </div>
            
            <input class="form-control mb-3" type="text" name="tmp-lahir" placeholder="Tempat Lahir" required>
            <input class="form-control mb-3" type="date" name="tgl-lahir" placeholder="Tanggal Lahir" required>
            
            <select class="form-control mb-3" name="agama" required>
              <option value="">Pilih Agama</option>
              <option value="islam">Islam</option>
              <option value="kristen">Kristen</option>
              <option value="khatolik">Khatolik</option>
              <option value="hindu">Hindu</option>
              <option value="budha">Budha</option>
            </select>
            
            <input class="form-control mb-3" type="text" name="pendidikan" placeholder="Pendidikan" required>
            <input class="form-control mb-3" type="text" name="pekerjaan" placeholder="Pekerjaan" required>

            <button class="btn btn-primary mb-3" type="submit"> 
            <i class="fa fa-check" aria-hidden="true"></i>
              Add
            </button>
          <?php }else{ ?>
            <!-- Edit Data -->
            <input class="form-control mb-3" type="hidden" name="id" value="<?= $edit->mdkk_id ?>">
            <input class="form-control mb-3" type="text" name="nik"  placeholder="NIK" value="<?= $edit->mdkk_nik ?>" required>
            <input class="form-control mb-3" type="text" name="nama" placeholder="Nama" value="<?= $edit->mdkk_nama ?>" required>
            
            <div class="form-check form-check-inline mb-3">
              <input class="form-check-input" type="radio" name="jk" id="radio1" value="L" <?= $edit->mdkk_jk == "L" ? 'checked' : '' ?> required>
              <label class="form-check-label mr-3" for="radio1">Laki-Laki</label>
              <input class="form-check-input" type="radio" name="jk" id="radio2" value="P" <?= $edit->mdkk_jk == "P" ? 'checked' : '' ?> required>
              <label class="form-check-label mr-3" for="radio2">Perempuan</label>
            </div>
            
            <input class="form-control mb-3" type="text" name="tmp-lahir" placeholder="Tempat Lahir" value="<?= $edit->mdkk_tmpLahir ?>" required>
            <input class="form-control mb-3" type="date" name="tgl-lahir" placeholder="Tanggal Lahir"  value="<?= $edit->mdkk_tglLahir ?>" required>
            
            <select class="form-control mb-3" name="agama" required>
              <option value="kristen" <?= $edit->mdkk_agama == 'kristen' ? 'selected' : '' ?> >Kristen</option>
              <option value="islam" <?= $edit->mdkk_agama == 'islam' ? 'selected' : '' ?> >Islam</option>
              <option value="khatolik" <?= $edit->mdkk_agama == 'khatolik' ? 'selected' : '' ?> >Khatolik</option>
              <option value="hindu" <?= $edit->mdkk_agama == 'hindu' ? 'selected' : '' ?> >Hindu</option>
              <option value="budha" <?= $edit->mdkk_agama == 'budha' ? 'selected' : '' ?> >Budha</option>
            </select>
            
            <input class="form-control mb-3" type="text" name="pendidikan" placeholder="Pendidikan" value="<?= $edit->mdkk_pendidikan ?>" required>
            <input class="form-control mb-3" type="text" name="pekerjaan" placeholder="Pekerjaan" value="<?= $edit->mdkk_pekerjaan ?>" required>
            
            <button class="btn btn-primary mb-3" type="submit"> 
            <i class="fa fa-check" aria-hidden="true"></i>
              Edit
            </button>
          <?php } ?>
        </form>
        
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">NIK</th>
                <th scope="col">Nama</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">Tempat Lahir</th>
                <th scope="col">Tanggal Lahir</th>
                <th scope="col">Agama</th>
                <th scope="col">Pendidikan</th>
                <th scope="col">Pekerjaan</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
            <?php 
              $no = 1;
              foreach ($detail as $r) { ?>
              <tr>
                <th scope="row"><?= $no; ?></th>
                <td><?= $r->mdkk_nik; ?></td>
                <td><?= $r->mdkk_nama; ?></td>
                <?php if($r->mdkk_jk == "L"){ ?>
                  <td>Laki-Laki</td>
                <?php }else{ ?>
                  <td>Perempuan</td>
                <?php } ?>
                <td><?= $r->mdkk_tmpLahir; ?></td>
                <td><?= $r->mdkk_tglLahir; ?></td>
                <td><?= $r->mdkk_agama; ?></td>
                <td><?= $r->mdkk_pendidikan; ?></td>
                <td><?= $r->mdkk_pekerjaan; ?></td>
                <td>
                  <a class="btn btn-primary btn-sm mb-1" href="<?= base_url('DataKK/kkDetail/' . $r->mdkk_hid . '/' . $r->mdkk_id) ?>">Edit</a>
                  <a class="btn btn-danger btn-sm" href="<?= base_url('DataKK/deleteKKDetail/' . $r->mdkk_hid . '/' . $r->mdkk_id) ?>" onclick="return confirm('Yakin menghapus data ini ..? ')" >Delete</a>
                </td>
              </tr>
            <?php $no++; } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>