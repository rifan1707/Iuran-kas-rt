<main>
  <div class="container-fluid">
    <h1 class="mt-4">Data Warga</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">Master</li>
        <li class="breadcrumb-item active">Data Warga</li>
    </ol>

    <?= $this->session->flashdata('message'); ?>

    
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary btn-sm mb-4" data-toggle="modal" data-target="#modalAddKK">
      <i class="fa fa-plus" aria-hidden="true"></i>  
      Add Data Warga
    </button>

    <!-- Modal -->
    <div class="modal fade" id="modalAddKK" tabindex="-1" role="dialog" aria-labelledby="modalLabelAddKK" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <form action="<?= base_url('DataKK/addKKHeader') ?>" method="post">
            <div class="modal-header">
              <h5 class="modal-title" id="modalLabelAddKK">Add Kartu Keluarga</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">    
                <input name="no-kk" id="no-kk" class="form-control mb-3" type="text" placeholder="Nomor KK">
                <input name="kepala-kk" id="kepala-kk" class="form-control mb-3" type="text" placeholder="Nama Kepala Keluarga">
                <textarea name="alamat-kk" id="alamat-kk" class="form-control mb-3" id="" rows="3" placeholder="Alamat KK"></textarea>
            </div>
            <div class="modal-footer">
              <button id="btn-save-kk" type="submit" class="btn btn-primary">Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header">
          <i class="fas fa-table mr-1"></i>
          Data Warga
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                  <th>#</th>
                  <th>NO KK</th>
                  <th>Nama Kepala Keluarga</th>
                  <th>Alamat</th>
                  <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
                $no=1;
                foreach ($data as $r) { ?>
                  <tr>
                    <td><?= $no; ?></td>
                    <td><?= $r->mhkk_NoKK; ?></td>
                    <td><?= $r->mhkk_Nama; ?></td>
                    <td><?= $r->mhkk_Alamat; ?></td>
                    <td>
                      <a class="btn btn-primary btn-sm mb-2" href="<?= base_url('DataKK/kkDetail/' . $r->mhkk_id) ?>">
                        <i class="fa fa-plus" aria-hidden="true"></i>  
                        Anggota
                      </a>
                      <a class="btn btn-primary btn-sm mb-2">
                        <i class="fa fa-info" aria-hidden="true"></i>
                        Detail
                      </a>
                    </td>
                  </tr>
               <?php $no++; } ?> 
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>
