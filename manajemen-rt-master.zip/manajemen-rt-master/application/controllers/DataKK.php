<?php 
class DataKK extends CI_Controller 
{
  public function __construct() {
    parent::__construct(); 
    $this->load->model('data_warga/KK_model');
  } 

  private function alert($type,$message){
    $alert = '<div class="alert ' . $type . ' alert-dismissible fade show" role="alert">
                ' . $message . '
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>';

    return $alert;
  }

  public function index($message = null) { 
    $data['data'] = $this->KK_model->getKKHeader();
    $this->route(null, $data);
  }

  public function kkDetail() { 
    $idH = $this->uri->segment(3);
    $idD = $this->uri->segment(4);

    $data['header'] = $this->KK_model->getKKHeader($idH);
    $data['detail'] = $this->KK_model->getKKDetail($idH);
    $data['edit'] = $this->KK_model->getEditDetail($idD);

    $this->route("detail",$data);    
  }
  
  private function route($page = null, $data = null){
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    
    if($page == "detail"){
      $this->load->view('pages/data_warga/kkdetail_view',$data);
    }else{
      $this->load->view('pages/data_warga/kkheader_view',$data);
    }
    
    $this->load->view('template/footer');
  }

  // Add Data KK Header
  public function addKKHeader() {
    // Get Input User
    $noKK = $this->input->post('no-kk');
    $nmKepalaKK = $this->input->post('kepala-kk');
    $alamatKK = $this->input->post('alamat-kk');


    // Validasi Input Kosong
    $sSalah = "";
    if($noKK == ""){
      $sSalah = $sSalah . "- Nomor KK Tidak Boleh Kosong <br/>";
    }
    if($nmKepalaKK == ""){
      $sSalah = $sSalah . "- Kepala Keluarga Tidak Boleh Kosong <br/>";
    }
    if($alamatKK == ""){
      $sSalah = $sSalah . "- Alamat KK Tidak Boleh Kosong <br/>";
    }

    if($sSalah != ""){
      $alert = $this->alert("alert-danger","<strong>Data Gagal Disimpan</strong><br/> " . $sSalah);
      $this->session->set_flashdata(
        'message',
        $alert
      );
      redirect('DataKK');
    }

    // Cek Nomor KK sudah terdaftar
    $data = $this->KK_model->chekKK($noKK);

    if($data > 0){
      $alert = $this->alert("alert-danger","<strong>Data Gagal Disimpan</strong> Nomor Kartu Keluarga Telah Terdaftar.");
      $this->session->set_flashdata(
        'message',
        $alert
      );
      redirect('DataKK');
    }
    
    // Insert Data ke Database
    $sSalah = $this->KK_model->addKKHeader($noKK,$nmKepalaKK,$alamatKK);
    if($sSalah == "OK"){
      $alert = $this->alert("alert-success","<strong>Success</strong> Data Kartu Keluarga Berhasil Ditambahkan.");
      $this->session->set_flashdata(
        'message',
        $alert
      );
    }else{
      $alert = $this->alert("alert-danger","<strong>Error</strong> Data Gagal Ditambahkan, Silahkan di coba kembali.");
      $this->session->set_flashdata(
        'message',
        $alert
      );
    }

    redirect('DataKK');
  }

  public function addKKDetail($idKK) {
    // Get Input NIK
    $id = $this->input->post('id');
    $nik = $this->input->post('nik');

    if($id == ""){
      // Chek NIK Sudah Terdaftar
      $alert = $this->alert("alert-danger","<strong>Data Gagal Disimpan</strong> NIK Telah Terdaftar.");
      if($this->KK_model->chekNIK($nik)){
        $this->session->set_flashdata(
          'message',
          $alert
        );
        redirect('DataKK/kkDetail/'. $idKK);
      }

      // Insert Data ke Database
      $sSalah = $this->KK_model->addKKDetail($idKK);
      if($sSalah == "OK"){
        $alert = $this->alert("alert-success","<strong>Success</strong> Data Kartu Keluarga Berhasil Ditambahkan.");
        $this->session->set_flashdata(
          'message',
          $alert
        );
      }else{
        $alert = $this->alert("alert-danger","<strong>Error</strong> Data Gagal Ditambahkan, Silahkan di coba kembali.");
        $this->session->set_flashdata(
          'message',
          $alert
        );
      }
    }else{
      // Update Data ke Database
      $sSalah = $this->KK_model->editKKDetail();
      if($sSalah == "OK"){
        $alert = $this->alert("alert-success","<strong>Success</strong> Data Kartu Keluarga Berhasil Diubah.");
        $this->session->set_flashdata(
          'message',
          $alert
        );
      }else{
        $alert = $this->alert("alert-danger","<strong>Error</strong> Data Gagal Diubah, Silahkan di coba kembali.");
        $this->session->set_flashdata(
          'message',
          $alert
        );
      }
    }

    redirect('DataKK/kkDetail/'. $idKK);
  }

  public function deleteKKDetail($idH,$idD) {
    // Update Data ke Database
    $sSalah = $this->KK_model->deleteKKDetail($idH,$idD);
    if($sSalah == "OK"){
      $alert = $this->alert("alert-success","<strong>Success</strong> Data Kartu Keluarga Berhasil Dihapus.");
      $this->session->set_flashdata(
        'message',
        $alert
      );
    }else{
      $alert = $this->alert("alert-danger","<strong>Error</strong> Data Gagal Dihapus, Silahkan di coba kembali.");
      $this->session->set_flashdata(
        'message',
        $alert
      );
    }

    redirect('DataKK/kkDetail/'. $idH);
  }
} 