-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Apr 2021 pada 02.48
-- Versi server: 10.3.15-MariaDB
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manajemen_rt`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `m_kk_header`
--

CREATE TABLE `m_kk_header` (
  `mhkk_id` int(11) NOT NULL,
  `mhkk_NoKK` varchar(18) NOT NULL,
  `mhkk_Nama` varchar(50) NOT NULL,
  `mhkk_Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `m_kk_header`
--

INSERT INTO `m_kk_header` (`mhkk_id`, `mhkk_NoKK`, `mhkk_Nama`, `mhkk_Alamat`) VALUES
(1, '3404080111110002', 'ERI KURNIAWAN, ST', 'TEGAL SARI, DAWUKAN RT/RW 006/005 Sendangtiro, Berbah Sleman 55573');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `m_kk_header`
--
ALTER TABLE `m_kk_header`
  ADD PRIMARY KEY (`mhkk_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `m_kk_header`
--
ALTER TABLE `m_kk_header`
  MODIFY `mhkk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
