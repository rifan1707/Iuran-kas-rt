-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2021 at 12:05 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manajemen_rt`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_kk_detail`
--

CREATE TABLE `m_kk_detail` (
  `mdkk_id` int(11) NOT NULL,
  `mdkk_hid` int(11) NOT NULL,
  `mdkk_nik` varchar(16) NOT NULL,
  `mdkk_nama` varchar(50) NOT NULL,
  `mdkk_jk` enum('L','P') NOT NULL,
  `mdkk_tmpLahir` varchar(20) NOT NULL,
  `mdkk_tglLahir` date NOT NULL,
  `mdkk_agama` varchar(20) NOT NULL,
  `mdkk_pendidikan` varchar(50) NOT NULL,
  `mdkk_pekerjaan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `m_kk_detail`
--

INSERT INTO `m_kk_detail` (`mdkk_id`, `mdkk_hid`, `mdkk_nik`, `mdkk_nama`, `mdkk_jk`, `mdkk_tmpLahir`, `mdkk_tglLahir`, `mdkk_agama`, `mdkk_pendidikan`, `mdkk_pekerjaan`) VALUES
(2, 1, '9876543210001', 'Mahmut', 'P', 'Bekasi', '1998-05-21', 'islam', 'SD', 'Tidak Bekerja'),
(3, 1, '9876543210002', 'Desta', 'L', 'Bekasi', '1997-08-28', 'islam', 'SMA', 'Pelajar');

-- --------------------------------------------------------

--
-- Table structure for table `m_kk_header`
--

CREATE TABLE `m_kk_header` (
  `mhkk_id` int(11) NOT NULL,
  `mhkk_NoKK` varchar(18) NOT NULL,
  `mhkk_Nama` varchar(50) NOT NULL,
  `mhkk_Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_kk_header`
--

INSERT INTO `m_kk_header` (`mhkk_id`, `mhkk_NoKK`, `mhkk_Nama`, `mhkk_Alamat`) VALUES
(1, '3404080111110002', 'ERI KURNIAWAN, ST', 'TEGAL SARI, DAWUKAN RT/RW 006/005 Sendangtiro, Berbah Sleman 55573'),
(5, '123456', 'Dede', 'Jalan Jalan'),
(6, '654321', 'Somat', 'Jalan 123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_kk_detail`
--
ALTER TABLE `m_kk_detail`
  ADD PRIMARY KEY (`mdkk_id`);

--
-- Indexes for table `m_kk_header`
--
ALTER TABLE `m_kk_header`
  ADD PRIMARY KEY (`mhkk_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `m_kk_detail`
--
ALTER TABLE `m_kk_detail`
  MODIFY `mdkk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `m_kk_header`
--
ALTER TABLE `m_kk_header`
  MODIFY `mhkk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
